# Requests benchmark run

## Preflight

Confirm that the MCP indexes `requests`:

```bash
codex exec \
  --profile benchmark \
  --ephemeral \
  --json \
  --cd /path/to/requests \
  -c 'features.multi_agent=false' \
  -c 'mcp_servers.codekg.enabled=true' \
  'Call codekg.list_repositories exactly once. Return only whether requests is present.' \
  > runs/requests-intent-001/preflight.jsonl
```

Do not proceed unless the completed `list_repositories` result includes `requests`.

## CodeKG arm

Use the same safety/approval flags that passed your MCP preflight. In an isolated runner,
that may currently require `--dangerously-bypass-approvals-and-sandbox`.

```bash
mkdir -p runs/requests-intent-001/codekg

time codex exec \
  --profile benchmark \
  --ephemeral \
  --json \
  --cd /path/to/requests \
  -c 'features.multi_agent=false' \
  -c 'mcp_servers.codekg.enabled=true' \
  --output-schema evaluation/codex-answer.schema.json \
  -o runs/requests-intent-001/codekg/answer.json \
  "$(cat evaluation/prompts/requests-intent-001-codekg.txt)" \
  > runs/requests-intent-001/codekg/events.jsonl \
  2> runs/requests-intent-001/codekg/stderr.log
```

## Native arm

```bash
mkdir -p runs/requests-intent-001/native

time codex exec \
  --profile benchmark \
  --ephemeral \
  --json \
  --cd /path/to/requests \
  -c 'features.multi_agent=false' \
  -c 'mcp_servers.codekg.enabled=false' \
  --sandbox read-only \
  --output-schema evaluation/codex-answer.schema.json \
  -o runs/requests-intent-001/native/answer.json \
  "$(cat evaluation/prompts/requests-intent-001-native.txt)" \
  > runs/requests-intent-001/native/events.jsonl \
  2> runs/requests-intent-001/native/stderr.log
```

## Validity checks

The CodeKG arm is valid only when:

- `list_repositories` succeeds and contains `requests`;
- at least one `search_symbols` call succeeds;
- at least one `get_definition` call succeeds;
- every reported symbol appears in MCP evidence;
- source line ranges are non-null.

The native arm is valid only when:

- at least one command execution searches the repository;
- the selected source files are read;
- source line ranges are non-null.

A guessed answer with no repository evidence is invalid even when the symbol happens to
be correct.
